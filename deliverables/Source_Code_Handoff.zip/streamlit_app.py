"""Capstone web interface backed by the Medical Document Assistant FastAPI service."""

import os
from pathlib import Path
from typing import Any

import requests
import streamlit as st

ROOT = Path(__file__).resolve().parent
API_URL = os.getenv("MEDICAL_API_URL", "http://127.0.0.1:8000").rstrip("/")
CLASS_NAMES = {"antibacterial": "Antibacterial", "anti_inflammatory_nsaid": "Anti-inflammatory (NSAID)",
               "corticosteroid": "Corticosteroid", "antifungal": "Antifungal", "acid_reducer": "Acid reducer",
               "antihypertensive": "Antihypertensive"}
FIELD_NAMES = {"indications": "Indications / uses", "dosage": "Dosage and administration", "warnings": "Warnings",
               "contraindications": "Contraindications", "side_effects": "Side effects", "interactions": "Interactions"}

st.set_page_config(page_title="Medical Document Assistant", page_icon="📄", layout="wide")
st.markdown("""<style>
.block-container {max-width:1200px; padding-top:2rem;}
h1, h2, h3 {color:#263450;}
[data-testid="stMetric"] {background:#f4f6fa; padding:16px; border-radius:12px;}
.stButton > button[kind="primary"] {background:#5e5aa1; border-color:#5e5aa1;}
</style>""", unsafe_allow_html=True)


def api(method: str, path: str, **kwargs: Any) -> dict[str, Any]:
    try:
        response = requests.request(method, API_URL + path, timeout=(10, 240), **kwargs)
    except requests.RequestException as error:
        raise RuntimeError("The backend is unavailable. Start the API service and try again.") from error
    if not response.ok:
        try:
            message = response.json().get("detail", response.text)
        except ValueError:
            message = response.text
        raise RuntimeError(str(message))
    return response.json()


@st.cache_data(ttl=15)
def backend_models() -> list[dict[str, Any]]:
    return api("GET", "/models")["models"]


def accept_document(document: dict[str, Any]) -> None:
    previous = st.session_state.get("document")
    if previous:
        try:
            api("DELETE", "/documents/" + previous["document_id"])
        except RuntimeError:
            pass
    st.session_state.document = document
    st.session_state.messages = []
    st.session_state.pending_question = None


st.title("Medical Document Assistant")
st.caption("Understand a document. Explore its source sections. Ask questions with evidence.")
st.info("Informational only — not medical advice. This demo evaluates English text and quotes the document you supply.")

with st.sidebar:
    st.header("Document workspace")
    st.write("Upload a text-based PDF, TXT/MD, HTML, or DOCX, or paste document text.")
    try:
        available = [model for model in backend_models() if model["available"]]
        identifiers = [model["id"] for model in available]
        names = {model["id"]: model["name"] for model in available}
        default = identifiers.index("text_cnn") if "text_cnn" in identifiers else 0
        classifier = st.selectbox("Classifier", identifiers, index=default, format_func=lambda name: names[name])
    except (RuntimeError, ValueError):
        classifier = "text_cnn"
        st.warning("API connection not ready. The default classifier is TextCNN.")
    st.caption("TextCNN is the validation-selected default. Category predictions are limited to the six trained leaflet categories.")
    if st.button("Use example leaflet", use_container_width=True):
        try:
            with st.spinner("Analyzing the real source example..."):
                example = (ROOT / "data" / "examples" / "phase2_demo_leaflet.txt").read_text(encoding="utf-8")
                accept_document(api("POST", "/documents", json={"text": example, "source_name": "FDA example leaflet", "model": classifier}))
            st.rerun()
        except (RuntimeError, OSError) as error:
            st.error(str(error))
    if st.session_state.get("document") and st.button("Clear document", use_container_width=True):
        try:
            api("DELETE", "/documents/" + st.session_state.document["document_id"])
        except RuntimeError:
            pass
        st.session_state.pop("document", None)
        st.session_state.messages = []
        st.rerun()
    st.divider()
    st.caption("10 MB file limit · 50 PDF pages · 200,000 text characters")
    st.caption("Scanned images need text extraction before this demo. Dedicated missing sections remain empty.")

if "messages" not in st.session_state:
    st.session_state.messages = []
if "pending_question" not in st.session_state:
    st.session_state.pending_question = None

with st.expander("Upload or paste a document", expanded=not bool(st.session_state.get("document"))):
    mode = st.radio("Input method", ["Upload file", "Paste text"], horizontal=True)
    with st.form("document_form"):
        if mode == "Upload file":
            uploaded = st.file_uploader("Choose a document", type=["pdf", "txt", "md", "html", "htm", "docx"])
            pasted, title = "", "pasted document"
        else:
            uploaded = None
            title = st.text_input("Document title", value="Pasted leaflet")
            pasted = st.text_area("Document text", height=220, placeholder="Paste the original leaflet, prescription text, or article here.")
        submitted = st.form_submit_button("Analyze document", type="primary", use_container_width=True)
    if submitted:
        try:
            with st.spinner("Reading and analyzing the document..."):
                if uploaded is not None:
                    document = api("POST", "/documents/upload", files={"file": (uploaded.name, uploaded.getvalue(), uploaded.type)}, data={"model": classifier})
                elif pasted.strip():
                    document = api("POST", "/documents", json={"text": pasted, "source_name": title, "model": classifier})
                else:
                    raise RuntimeError("Choose a file or paste readable document text.")
                accept_document(document)
            st.rerun()
        except RuntimeError as error:
            st.error(str(error))

document = st.session_state.get("document")
if not document:
    st.subheader("Start with a document")
    st.write("Use the real FDA example from the sidebar, upload a file, or paste text. Results and evidence-based chat appear here.")
    st.stop()

classification = document["classification"]
columns = st.columns(3)
columns[0].metric("Source document", document["source_name"])
columns[1].metric("Predicted category", CLASS_NAMES.get(classification.get("predicted_class"), "English model only"))
columns[2].metric("Source words / sections", f"{document['words']:,} / {document['extraction']['section_count']}")
st.caption("Classifier: " + classification.get("model_name", "unsupported language") + " · " + str(classification.get("latency_ms", "—")) + " ms")

tab_sections, tab_text, tab_models = st.tabs(["Source sections", "Document text", "Model comparison"])
with tab_sections:
    for key, field in document["extraction"]["fields"].items():
        with st.expander(FIELD_NAMES[key], expanded=key == "dosage"):
            if field["present"]:
                st.text(field["text"])
                st.caption("Copied from source headings; no dose or medical recommendation is inferred.")
            else:
                st.caption("A dedicated source section was not found. This does not establish that the medicine has no risks or effects.")
with tab_text:
    st.text_area("Canonical source text", document["text"], height=300, disabled=True)
    st.download_button("Download extracted text", document["text"], file_name="document_text.txt", mime="text/plain")
with tab_models:
    try:
        import pandas as pd
        rows = [{"Model": model["name"], "Validation macro F1": model["validation_macro_f1"], "Test accuracy": model["test_accuracy"],
                 "Test macro F1": model["test_macro_f1"]} for model in backend_models()]
        st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
        st.caption("Recorded results on the frozen source-derived corpus. Context budgets and model sizes differ; these are not clinical validation figures.")
    except RuntimeError as error:
        st.caption(str(error))

st.divider()
st.subheader("Ask this document")
st.caption("Responses are source quotations with evidence, or a missing-answer fallback. Changing documents clears this conversation.")
suggestions = st.columns(4)
for column, label, question in zip(suggestions, ["Dosage", "Warnings", "Pregnancy", "Missing fact"],
                                  ["What does the document say about dosage and administration?", "What does the document say about warnings?",
                                   "What does the document say about pregnancy or breast-feeding?", "What is the retail price stated in the document?"]):
    if column.button(label, use_container_width=True):
        st.session_state.pending_question = question

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])
        if message["role"] == "assistant":
            for citation in message.get("citations", []):
                with st.expander("Source evidence · " + citation["chunk_id"]):
                    st.text(citation["quote"])
                    st.caption(f"Source characters {citation['char_start']}–{citation['char_end']}")
            if message.get("latency_ms") is not None:
                st.caption(str(message["latency_ms"]) + " ms · " + message.get("answer_mode", message.get("status", "")))

typed = st.chat_input("Ask a question about the current document")
question = typed or st.session_state.pending_question
if question:
    st.session_state.pending_question = None
    st.session_state.messages.append({"role": "user", "content": question})
    try:
        with st.spinner("Retrieving source evidence and checking the answer..."):
            response = api("POST", "/ask", json={"document_id": document["document_id"], "question": question})
        st.session_state.messages.append({"role": "assistant", "content": response["answer"], **response})
    except RuntimeError as error:
        st.session_state.messages.append({"role": "assistant", "content": str(error), "citations": [], "status": "error"})
    st.rerun()
